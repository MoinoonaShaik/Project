import { Component, OnInit } from '@angular/core';
import { ManagerService } from './manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewtechnicians',
  templateUrl: './viewtechnicians.component.html',
  styleUrls: ['./viewtechnicians.component.css']
})
export class ViewtechniciansComponent implements OnInit {

 model:any={};
  name:any;
  result:any;
  tmailId:any;
  test:any={};
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
    
    
  }
  add1(){
    this.router.navigate(["./addEquipment"]);
  }
  add2(){
    this.router.navigate(["./addTests"]);
  }
  view2(){
    this.router.navigate(['./viewTests']);
  }
  logout(){
    this.router.navigate(['./home']);
  }
  view1(){
    this.router.navigate(['./custviewequip']);
  }


  view(){
    console.log(this.managerService.usermail)
    return this.managerService.viewTechnicians().subscribe((data:any)=>{
      this.model=data;
    })
  }

  tests(){
    this.managerService.viewTests().subscribe((data:any)=>{
      this.test=data;
    })
  }
  book(model:any){
  return this.managerService.bookTechnicians(model).subscribe((data:any)=>{
    this.managerService.techmailId=model;
    this.result=data;
    if(this.result==1)
    alert("booked succesfully");
  })

  }
}
