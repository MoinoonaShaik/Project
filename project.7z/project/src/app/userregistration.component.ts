import { Component, OnInit } from '@angular/core';
import { ManagerService } from './manager.service';

@Component({
  selector: 'app-userregistration',
  templateUrl: './userregistration.component.html',
  styleUrls: ['./userregistration.component.css']
})
export class UserregistrationComponent implements OnInit {

  model:any={};
  res:any;
  constructor(private managerService:ManagerService) { }

  ngOnInit() {
  }
  addUser(){
    console.log("in registration"+this.model.name);
    return this.managerService.createRegistration(this.model).subscribe((data:number)=>{
      this.res=data;
      if(this.res==1)
      alert("already registered");
      else
      alert("registered successfully");
    })
    
  }

}
