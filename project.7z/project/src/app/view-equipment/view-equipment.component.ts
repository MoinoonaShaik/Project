import { Component, OnInit } from '@angular/core';
import { ManagerService } from '../manager.service';
import { Router } from '@angular/router';
import { ResultFunc } from 'rxjs/internal/observable/generate';

@Component({
  selector: 'app-view-equipment',
  templateUrl: './view-equipment.component.html',
  styleUrls: ['./view-equipment.component.css']
})
export class ViewEquipmentComponent implements OnInit {

  equipment:any={};
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
    return this.managerService.viewEquipment().subscribe((data:any)=>{
      this.equipment=data;
    })
  }
  
  add1(){
    this.router.navigate(["./addEquipment"]);
  }
  add2(){
    this.router.navigate(["./addTests"]);
  }
  logout(){
    this.router.navigate(['./home']);
   
  }
  view2(){
    this.router.navigate(['./viewTests']);
  }
  save(eName,eprice){
    console.log(eName+" and "+eprice);
    this.managerService.eName=eName;
    this.managerService.eprice=eprice; 
    this.router.navigate(['./editEquipment']);
    
  }
  delete(eName,eprice){
   this.managerService.deleteEquipment(eName).subscribe((data:any)=>{
     if(data==1){
     alert("deleted succesfully");
     this.router.navigate(['./deleteEquipment'])
     }
   }); 
  }
}
