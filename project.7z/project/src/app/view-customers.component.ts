import { Component, OnInit } from '@angular/core';
import { ManagerService } from './manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-customers',
  templateUrl: './view-customers.component.html',
  styleUrls: ['./view-customers.component.css']
})
export class ViewCustomersComponent implements OnInit {

  res:any={};
  constructor(private managerServcie:ManagerService,private router:Router) { }

  ngOnInit() {
    this.managerServcie.viewCustomers().subscribe((data:any)=>{
      this.res=data;
    })
  }
  add1(){
    this.router.navigate(["./addEquipment"]);
  }
  add2(){
    this.router.navigate(["./addTests"]);
  }
  view2(){
    this.router.navigate(['./viewTests']);
  }
  logout(){
    this.router.navigate(['./home']);
  }
  view1(){
    this.router.navigate(['./viewEquipment']);
  }
  
  view(){
    this.router.navigate(['./viewCustomers']);
  }
}
