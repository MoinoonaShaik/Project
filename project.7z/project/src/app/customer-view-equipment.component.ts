import { Component, OnInit } from '@angular/core';
import { ManagerService } from './manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-view-equipment',
  templateUrl: './customer-view-equipment.component.html',
  styleUrls: ['./customer-view-equipment.component.css']
})
export class CustomerViewEquipmentComponent implements OnInit {

  equipment:any={};
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
    return this.managerService.viewEquipment().subscribe((data:any)=>{
      this.equipment=data;
    })

  }
  add1(){
    this.router.navigate(["./addEquipment"]);
  }
  add2(){
    this.router.navigate(["./addTests"]);
  }
  logout(){
    this.router.navigate(['./home']);
   
  }
  view2(){
    this.router.navigate(['./viewTests']);
  }
  

}
