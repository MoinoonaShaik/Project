import { Component, OnInit } from '@angular/core';
import { ManagerService } from './manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-technician',
  templateUrl: './technician.component.html',
  styleUrls: ['./technician.component.css']
})
export class TechnicianComponent implements OnInit {

  result:any;
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
  }
  add1(){
    this.router.navigate(["./addEquipment"]);
  }
  add2(){
    this.router.navigate(["./addTests"]);
  }
  view2(){
    this.router.navigate(['./viewTests']);
  }
  logout(){
    this.router.navigate(['./home']);
  }
  view1(){
    this.router.navigate(['./viewEquipment']);
  }

  view(){
    this.router.navigate(['./viewCustomers']);
  }
}



