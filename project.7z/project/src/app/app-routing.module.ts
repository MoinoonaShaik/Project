import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';
import { ManagerLoginComponent } from './manager-login/manager-login.component';
import { ManagerPageComponent } from './manager-page.component';
import { RegistrationComponent } from './project/registration.component';
import { AddEquipmentComponent } from './add-equipment.component';
import { AddTestsComponent } from './project/add-tests.component';
import { ViewTestsComponent } from './view-tests.component';
import { UserregistrationComponent } from './userregistration.component';
import { TechnicianComponent } from './technician.component';
import { ViewCustomersComponent } from './view-customers.component';
import { CustomerComponent } from './customer.component';
import { ViewtechniciansComponent } from './viewtechnicians.component';
import { ViewEquipmentComponent } from './view-equipment/view-equipment.component';
import { EditEquipmentComponent } from './edit-equipment/edit-equipment.component';
import { DeleteEquipComponent } from './delete-equip.component';
import { EditTesstComponent } from './edit-tesst.component';
import { DeleteTestComponent } from './delete-test.component';
import { CustomerViewEquipmentComponent } from './customer-view-equipment.component';
import { CustviewtestComponent } from './custviewtest.component';


const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'managerLogin',component:ManagerLoginComponent},
  {path:'managerPage',component:ManagerPageComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'addEquipment',component:AddEquipmentComponent},
  {path:'addTests',component:AddTestsComponent},
  {path:'viewTests',component:ViewTestsComponent},
  {path:'userRegister',component:UserregistrationComponent},
  {path:'technicianPage',component:TechnicianComponent},
  {path:'viewCustomers',component:ViewCustomersComponent},
  {path:'customer',component:CustomerComponent},
  {path:'viewTechnicians',component:ViewtechniciansComponent},
  {path:'viewEquipment',component:ViewEquipmentComponent},
  {path:'editEquipment',component:EditEquipmentComponent},
  {path:'deleteEquipment',component:DeleteEquipComponent},
  {path:'editTest',component:EditTesstComponent},
  {path:'deleteTest',component:DeleteTestComponent},
  {path:'custviewequip',component:CustomerViewEquipmentComponent},
  {path:'custviewtest',component:CustviewtestComponent},
  {path:'',redirectTo:'/registration',pathMatch:"full"}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
